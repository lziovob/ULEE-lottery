export type PrizeTier = 'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'G' | 'H' | 'LastOne';

export interface Prize {
  tier: PrizeTier;
  name: string;
  image: string;
  totalCount: number; // Total available in a full box
  currentCount: number; // Remaining currently
  description: string;
}

export interface Ticket {
  id: number;
  isOpened: boolean;
  prizeTier?: PrizeTier; // Revealed only after opening
}

export interface LotterySet {
  id: string;
  title: string;
  theme: string;
  pricePerTicket: number;
  currency: string;
  totalTickets: number;
  prizes: Prize[];
  tickets: Ticket[]; // The state of the box
  coverImage: string;
  lastOnePrize: Prize;
  description: string;
}

export interface InventoryItem {
  lotteryTitle: string;
  prize: Prize;
  obtainedAt: Date;
}

export interface User {
  id: string;
  name: string;
  avatar: string;
  balance: number;
  provider: 'line' | 'google';
}
