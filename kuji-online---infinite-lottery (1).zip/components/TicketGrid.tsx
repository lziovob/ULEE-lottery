import React from 'react';
import { Ticket } from '../types';
import { Sparkles, Check } from 'lucide-react';

interface TicketGridProps {
  tickets: Ticket[];
  onTicketClick: (ticketId: number) => void;
}

export const TicketGrid: React.FC<TicketGridProps> = ({ tickets, onTicketClick }) => {
  return (
    <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-soft border-4 border-slime-bg relative overflow-hidden">
        {/* Decorative dots */}
        <div className="absolute top-0 right-0 p-4 opacity-10">
            <Sparkles className="w-32 h-32 text-slime-accent" />
        </div>

        <div className="relative z-10 grid grid-cols-5 sm:grid-cols-8 md:grid-cols-10 gap-3">
            {tickets.map((ticket) => (
                <button
                    key={ticket.id}
                    disabled={ticket.isOpened}
                    onClick={() => onTicketClick(ticket.id)}
                    className={`
                        aspect-square relative rounded-xl transition-all duration-300 transform
                        flex items-center justify-center group
                        ${ticket.isOpened 
                            ? 'bg-gray-100 text-gray-400 cursor-default border-2 border-gray-100' 
                            : 'bg-white border-2 border-slime-secondary text-slime-text hover:bg-slime-bg hover:scale-110 hover:shadow-lg hover:border-slime-accent hover:-rotate-2 cursor-pointer'
                        }
                    `}
                >
                    {ticket.isOpened ? (
                        <span className="font-bold text-lg">{ticket.prizeTier}</span>
                    ) : (
                        <>
                            <span className="font-bold text-sm sm:text-base opacity-40 group-hover:opacity-100 transition-opacity">
                                {ticket.id}
                            </span>
                            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-20">
                                <Sparkles size={16} />
                            </div>
                        </>
                    )}
                </button>
            ))}
        </div>
        
        {/* Status Footer */}
        <div className="mt-8 flex justify-center">
            <div className="inline-flex items-center gap-4 bg-slime-bg px-6 py-2 rounded-full text-sm font-bold text-slime-text/70">
                <span>Total: {tickets.length}</span>
                <span className="w-1 h-1 bg-current rounded-full"></span>
                <span className="text-slime-accent">Left: {tickets.filter(t => !t.isOpened).length}</span>
            </div>
        </div>
    </div>
  );
};