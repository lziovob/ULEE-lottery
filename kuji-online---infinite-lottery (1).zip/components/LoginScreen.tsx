import React, { useState } from 'react';
import { MessageCircle, Loader2, X, Heart } from 'lucide-react';

interface LoginScreenProps {
  onLogin: (provider: 'line' | 'google') => void;
  onClose: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin, onClose }) => {
  const [loading, setLoading] = useState<string | null>(null);

  const handleLogin = (provider: 'line' | 'google') => {
    setLoading(provider);
    setTimeout(() => {
      onLogin(provider);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
       <div 
         className="absolute inset-0 bg-slime-text/40 backdrop-blur-md transition-opacity"
         onClick={onClose}
       ></div>

       <div className="relative z-10 w-full max-w-md bg-white rounded-3xl shadow-hover overflow-hidden flex flex-col font-sans animate-pop border-4 border-white">
          
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 z-20 p-2 bg-white/50 hover:bg-white rounded-full transition-colors text-slime-text"
          >
            <X size={24} />
          </button>

          <div className="pt-12 pb-6 px-8 text-center bg-gradient-to-b from-slime-bg to-white">
             <div className="w-20 h-20 bg-slime-primary rounded-2xl mx-auto mb-4 flex items-center justify-center shadow-lg transform rotate-3">
                <Heart className="text-white w-10 h-10 fill-current" />
             </div>
             <h2 className="text-2xl font-bold text-slime-text mb-2">Welcome Back!</h2>
             <p className="text-slime-text/60 text-sm">Log in to collect points and win cute prizes.</p>
          </div>

          <div className="p-8 pt-2 bg-white space-y-4">
             <button 
               onClick={() => handleLogin('line')}
               disabled={!!loading}
               className="w-full bg-[#06C755] hover:bg-[#05b34c] text-white font-bold py-4 px-6 rounded-2xl transition-all transform hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-3 shadow-md"
             >
                {loading === 'line' ? <Loader2 className="animate-spin" /> : <MessageCircle className="fill-current w-6 h-6" />}
                <span className="text-lg">Login with LINE</span>
             </button>

             <button 
               onClick={() => handleLogin('google')}
               disabled={!!loading}
               className="w-full bg-white border-2 border-gray-100 hover:border-gray-200 text-gray-700 font-bold py-4 px-6 rounded-2xl transition-all transform hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-3"
             >
                {loading === 'google' ? <Loader2 className="animate-spin" /> : <img src="https://www.google.com/favicon.ico" alt="G" className="w-5 h-5" />}
                <span className="text-lg">Login with Google</span>
             </button>

             <p className="text-center text-xs text-slime-text/40 mt-4">
                By continuing, you agree to our Terms of Service and Privacy Policy.
             </p>
          </div>
       </div>
    </div>
  );
};