import React from 'react';
import { Prize, PrizeTier } from '../types';
import { Trophy, Gift, Sparkles } from 'lucide-react';

interface PrizeBoardProps {
  prizes: Prize[];
  lastOne: Prize;
}

const tierStyles: Record<string, string> = {
  'A': 'bg-red-50 text-red-600 border-red-100',
  'B': 'bg-blue-50 text-blue-600 border-blue-100',
  'C': 'bg-green-50 text-green-600 border-green-100',
  'LastOne': 'bg-gradient-to-r from-slime-secondary to-slime-primary text-white border-transparent',
  'Default': 'bg-white text-gray-600 border-gray-100'
};

const PrizeRow: React.FC<{ prize: Prize; isLastOne?: boolean }> = ({ prize, isLastOne }) => {
  const percent = isLastOne 
    ? (prize.currentCount > 0 ? 100 : 0) 
    : (prize.currentCount / prize.totalCount) * 100;
  
  const isSoldOut = prize.currentCount === 0;
  const styleClass = isLastOne ? tierStyles.LastOne : (tierStyles[prize.tier] || tierStyles.Default);

  return (
    <div className={`relative flex items-center p-3 mb-3 rounded-2xl border-2 transition-all duration-300 ${isSoldOut ? 'opacity-50 grayscale' : 'hover:shadow-md'} ${styleClass}`}>
      {/* Tier Badge */}
      <div className={`flex-shrink-0 w-12 h-12 flex items-center justify-center font-bold text-xl rounded-xl shadow-inner-soft ${isLastOne ? 'bg-white/20 text-white' : 'bg-white'}`}>
        {isLastOne ? '★' : prize.tier}
      </div>

      {/* Details */}
      <div className="ml-4 flex-1 overflow-hidden">
        <div className="flex justify-between items-center mb-1">
          <h4 className="font-bold text-sm md:text-base truncate pr-2">{prize.name}</h4>
          <span className={`text-xs font-bold px-2 py-1 rounded-lg whitespace-nowrap ${isLastOne ? 'bg-white/20' : 'bg-gray-100'}`}>
            x {prize.currentCount}
          </span>
        </div>
        
        {/* Progress Bar */}
        {!isLastOne && (
          <div className="w-full bg-white h-2 rounded-full overflow-hidden border border-gray-100">
             <div 
               className="h-full bg-slime-accent transition-all duration-500 rounded-full"
               style={{ width: `${percent}%` }}
             />
          </div>
        )}
      </div>
    </div>
  );
};

export const PrizeBoard: React.FC<PrizeBoardProps> = ({ prizes, lastOne }) => {
  return (
    <div className="bg-white rounded-3xl shadow-soft p-6 h-full overflow-y-auto max-h-[80vh] border border-slime-bg">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-slime-bg rounded-xl text-slime-accent">
            <Trophy className="w-6 h-6" />
        </div>
        <h2 className="text-xl font-bold text-slime-text">Prize List</h2>
      </div>
      
      <div className="space-y-1 pr-1">
        {prizes.map((prize) => (
          <PrizeRow key={prize.tier} prize={prize} />
        ))}
        <div className="my-6 flex items-center gap-2 text-slime-accent/50 text-sm font-bold">
            <span className="h-0.5 flex-1 bg-current opacity-20"></span>
            <span>LAST ONE PRIZE</span>
            <span className="h-0.5 flex-1 bg-current opacity-20"></span>
        </div>
        <PrizeRow prize={lastOne} isLastOne />
      </div>
    </div>
  );
};