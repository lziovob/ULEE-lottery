import React, { useEffect, useState } from 'react';
import { Prize, PrizeTier } from '../types';
import { X, Star, Sparkles } from 'lucide-react';

interface AnimationModalProps {
  prizeTier: PrizeTier | null;
  prizeDetails?: Prize;
  onClose: () => void;
  isLastOne?: boolean;
}

export const AnimationModal: React.FC<AnimationModalProps> = ({ prizeTier, prizeDetails, onClose, isLastOne }) => {
  const [stage, setStage] = useState<'closed' | 'peeling' | 'revealed'>('closed');

  useEffect(() => {
    // Auto start interaction hint or sound could go here
    if (prizeTier) {
       // Reset on new prop
    }
  }, [prizeTier]);

  const handlePeel = () => {
    if (stage === 'closed') {
      setStage('peeling');
      setTimeout(() => {
        setStage('revealed');
      }, 800); // Wait for CSS transition
    }
  };

  if (!prizeTier) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-80 backdrop-blur-sm">
      <div className="relative max-w-md w-full">
        
        {/* Close Button (only available after reveal) */}
        {stage === 'revealed' && (
          <button 
            onClick={onClose}
            className="absolute -top-12 right-0 text-white hover:text-kuji-yellow transition-colors"
          >
            <X size={32} />
          </button>
        )}

        {/* The Ticket Itself */}
        <div 
          className={`
            relative w-full aspect-[3/4] bg-white rounded-xl shadow-2xl overflow-hidden transition-all duration-500
            ${stage === 'revealed' ? 'scale-100' : 'scale-95'}
          `}
        >
          {/* Inner Content (The Prize) */}
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-gradient-to-b from-yellow-50 to-white">
            <div className={`transform transition-all duration-700 ${stage === 'revealed' ? 'scale-100 opacity-100 translate-y-0' : 'scale-50 opacity-0 translate-y-10'}`}>
              <div className="text-6xl mb-4 animate-bounce">
                {isLastOne ? '🌟' : '🎉'}
              </div>
              <h2 className="text-4xl font-black text-kuji-red mb-2">
                {isLastOne ? 'LAST ONE!' : `GRADE ${prizeTier}`}
              </h2>
              {prizeDetails && (
                 <>
                   <div className="w-32 h-32 mx-auto my-4 rounded-lg overflow-hidden shadow-lg">
                      <img src={prizeDetails.image} alt={prizeDetails.name} className="w-full h-full object-cover" />
                   </div>
                   <p className="text-xl font-bold text-gray-800">{prizeDetails.name}</p>
                 </>
              )}
            </div>
            
            {stage === 'revealed' && (
              <button 
                onClick={onClose}
                className="mt-8 px-8 py-3 bg-kuji-blue text-white rounded-full font-bold shadow-lg hover:bg-blue-600 transition-colors animate-pulse"
              >
                Collect Prize
              </button>
            )}
          </div>

          {/* The Cover (Peelable Layer) */}
          <div 
            onClick={handlePeel}
            className={`
              absolute inset-0 bg-kuji-dark cursor-pointer flex flex-col items-center justify-center
              transition-transform duration-700 ease-in-out origin-bottom-right
              border-8 border-kuji-yellow
              ${stage !== 'closed' ? 'translate-x-full rotate-12 opacity-0' : 'hover:scale-[1.02]'}
            `}
            style={{ 
              backgroundImage: 'repeating-linear-gradient(45deg, #2D3748 0, #2D3748 10px, #1a202c 10px, #1a202c 20px)' 
            }}
          >
             <div className="bg-white p-6 rounded-full shadow-xl border-4 border-dashed border-kuji-yellow animate-shake">
                <span className="text-3xl font-black text-gray-800 tracking-widest">OPEN</span>
             </div>
             <p className="text-white mt-4 font-bold text-lg animate-pulse">Tap to Peel!</p>
          </div>
        </div>
      </div>
    </div>
  );
};
