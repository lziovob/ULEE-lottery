import React, { useState, useEffect } from 'react';
import { LotterySet, InventoryItem, PrizeTier, User } from './types';
import { getInitialChiikawaSet, generateAiLottery } from './services/geminiService';
import { PrizeBoard } from './components/PrizeBoard';
import { TicketGrid } from './components/TicketGrid';
import { AnimationModal } from './components/AnimationModal';
import { LoginScreen } from './components/LoginScreen';
import { 
  Loader2, Plus, Sparkles, ShoppingBag, ArrowLeft, 
  Wallet, LogIn, ChevronRight, Star, Heart, HelpCircle, 
  Instagram, Facebook, Twitter, Mail, Gift, Key
} from 'lucide-react';

const App: React.FC = () => {
  // --- State ---
  const [user, setUser] = useState<User | null>(null);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [view, setView] = useState<'home' | 'detail'>('home');
  const [lotteries, setLotteries] = useState<LotterySet[]>([]);
  const [currentSetId, setCurrentSetId] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [revealingTicket, setRevealingTicket] = useState<{id: number, tier: PrizeTier} | null>(null);
  const [showingLastOne, setShowingLastOne] = useState(false);

  // --- Init ---
  useEffect(() => {
    const initial = getInitialChiikawaSet();
    setLotteries([initial]);
  }, []);

  const currentLottery = lotteries.find(l => l.id === currentSetId);

  // --- Handlers ---
  const handleLogin = (provider: 'line' | 'google') => {
    setUser({
      id: `user-${Date.now()}`,
      name: provider === 'line' ? 'Line User' : 'Google User',
      avatar: `https://api.dicebear.com/9.x/avataaars/svg?seed=${Date.now()}&backgroundColor=ffdfbf`,
      balance: 10000,
      provider
    });
    setShowLoginModal(false);
  };

  const handleLogout = () => {
    if(window.confirm('Log out?')) setUser(null);
  };

  const checkApiKey = async () => {
    // Check if we are in an environment that supports window.aistudio key selection
    if ((window as any).aistudio) {
       try {
         const hasKey = await (window as any).aistudio.hasSelectedApiKey();
         if (!hasKey) {
            await (window as any).aistudio.openSelectKey();
         }
         return true;
       } catch (error) {
         console.error("API Key selection failed", error);
         return false;
       }
    }
    return true; // Assume standard env if aistudio is not present
  };

  const handleGenerateNew = async () => {
    if (!user) { setShowLoginModal(true); return; }
    
    // Ensure API Key is available
    await checkApiKey();

    const themes = ["Sanrio", "Pokemon", "Ghibli", "Sailor Moon", "Kirby", "Miffy"];
    setIsGenerating(true);
    try {
      const newSet = await generateAiLottery(themes[Math.floor(Math.random() * themes.length)]);
      setLotteries(prev => [...prev, newSet]);
    } catch (e) { 
        console.error(e);
        alert("Generation failed. Please ensure your API Key is connected."); 
    } 
    finally { setIsGenerating(false); }
  };

  const handlePlayClick = (id: string) => {
      setCurrentSetId(id);
      setView('detail');
      window.scrollTo(0,0);
  };

  const handleTicketClick = (ticketId: number) => {
    if (!user) { setShowLoginModal(true); return; }
    if (!currentLottery) return;
    if (user.balance < currentLottery.pricePerTicket) { alert("Low balance!"); return; }

    const ticketIndex = currentLottery.tickets.findIndex(t => t.id === ticketId);
    if (ticketIndex === -1 || currentLottery.tickets[ticketIndex].isOpened) return;

    // Deduct & Reveal
    setUser(prev => prev ? ({...prev, balance: prev.balance - currentLottery.pricePerTicket}) : null);
    const ticket = currentLottery.tickets[ticketIndex];
    if (!ticket.prizeTier) return; // Should not happen

    setRevealingTicket({ id: ticketId, tier: ticket.prizeTier });

    // Update Logic
    const updatedTickets = [...currentLottery.tickets];
    updatedTickets[ticketIndex] = { ...ticket, isOpened: true };
    const updatedPrizes = currentLottery.prizes.map(p => 
      p.tier === ticket.prizeTier ? { ...p, currentCount: p.currentCount - 1 } : p
    );
    
    // Check Last One
    const allOpened = updatedTickets.every(t => t.isOpened);
    let updatedLastOne = currentLottery.lastOnePrize;
    if (allOpened && currentLottery.lastOnePrize.currentCount > 0) {
       updatedLastOne = { ...updatedLastOne, currentCount: 0 };
       // Queue Last One Modal for after close
    }

    // Save
    const updatedLottery = { ...currentLottery, tickets: updatedTickets, prizes: updatedPrizes, lastOnePrize: updatedLastOne };
    setLotteries(prev => prev.map(l => l.id === currentSetId ? updatedLottery : l));
    
    // Add Inventory
    setInventory(prev => [{
       lotteryTitle: currentLottery.title,
       prize: currentLottery.prizes.find(p => p.tier === ticket.prizeTier)!,
       obtainedAt: new Date()
    }, ...prev]);
  };

  const handleModalClose = () => {
    setRevealingTicket(null);
    if (currentLottery && currentLottery.tickets.every(t => t.isOpened) && !showingLastOne && currentLottery.lastOnePrize.currentCount === 0) {
        // Simple logic check: if we just finished the box and haven't shown last one yet (approx)
    }
  };

  // --- Components ---

  const Header = () => (
    <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slime-bg">
        <div className="max-w-7xl mx-auto px-4 md:px-8 h-20 flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => setView('home')}>
                <div className="bg-slime-accent text-white p-2 rounded-xl">
                    <Sparkles size={20} fill="currentColor" />
                </div>
                <span className="font-bold text-xl text-slime-text tracking-tight">Kuji<span className="text-slime-accent">Online</span></span>
            </div>

            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center gap-8 font-bold text-slime-text/60 text-sm">
                <a href="#" className="hover:text-slime-accent transition-colors">Home</a>
                <a href="#" className="hover:text-slime-accent transition-colors">New Arrivals</a>
                <a href="#" className="hover:text-slime-accent transition-colors">How to Play</a>
                <a href="#" className="hover:text-slime-accent transition-colors">FAQ</a>
            </nav>

            {/* User Actions */}
            <div className="flex items-center gap-3">
                {/* Manual API Key Button (for debugging/setup) */}
                {(window as any).aistudio && (
                    <button 
                        onClick={() => (window as any).aistudio.openSelectKey()} 
                        className="p-2 text-slime-text/40 hover:text-slime-accent transition-colors rounded-full hover:bg-slime-bg"
                        title="Connect Google AI"
                    >
                        <Key size={20} />
                    </button>
                )}

                {user ? (
                    <div className="flex items-center gap-3 bg-slime-bg px-1 py-1 pr-4 rounded-full">
                        <img src={user.avatar} className="w-9 h-9 rounded-full bg-white border border-slime-secondary" />
                        <div className="flex flex-col">
                            <span className="text-xs font-bold text-slime-text">{user.name}</span>
                            <span className="text-[10px] font-bold text-slime-accent flex items-center gap-1">
                                <Wallet size={10} /> {user.balance.toLocaleString()} P
                            </span>
                        </div>
                        <button onClick={handleLogout} className="ml-2 text-slime-text/40 hover:text-red-400">
                             <ArrowLeft size={16} />
                        </button>
                    </div>
                ) : (
                    <button 
                        onClick={() => setShowLoginModal(true)}
                        className="flex items-center gap-2 bg-slime-text text-white px-5 py-2.5 rounded-full font-bold text-sm hover:bg-slime-accent transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
                    >
                        <LogIn size={16} /> Login
                    </button>
                )}
            </div>
        </div>
    </header>
  );

  const Footer = () => (
    <footer className="bg-white pt-16 pb-8 border-t border-slime-bg mt-auto">
        <div className="max-w-7xl mx-auto px-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
                <div className="col-span-1 md:col-span-2">
                    <h3 className="font-bold text-2xl text-slime-text mb-4">KujiOnline</h3>
                    <p className="text-slime-text/60 leading-relaxed max-w-sm">
                        The cutest online lottery shop. Official prizes, fair play, and instant delivery to your digital collection.
                    </p>
                    <div className="flex gap-4 mt-6">
                        <div className="w-10 h-10 bg-slime-bg rounded-full flex items-center justify-center text-slime-accent hover:bg-slime-accent hover:text-white transition-colors cursor-pointer"><Instagram size={20} /></div>
                        <div className="w-10 h-10 bg-slime-bg rounded-full flex items-center justify-center text-slime-accent hover:bg-slime-accent hover:text-white transition-colors cursor-pointer"><Facebook size={20} /></div>
                        <div className="w-10 h-10 bg-slime-bg rounded-full flex items-center justify-center text-slime-accent hover:bg-slime-accent hover:text-white transition-colors cursor-pointer"><Twitter size={20} /></div>
                    </div>
                </div>
                <div>
                    <h4 className="font-bold text-slime-text mb-4">Help</h4>
                    <ul className="space-y-3 text-sm text-slime-text/60">
                        <li><a href="#" className="hover:text-slime-accent">Shipping Info</a></li>
                        <li><a href="#" className="hover:text-slime-accent">FAQ</a></li>
                        <li><a href="#" className="hover:text-slime-accent">Terms of Service</a></li>
                        <li><a href="#" className="hover:text-slime-accent">Privacy Policy</a></li>
                    </ul>
                </div>
                <div>
                    <h4 className="font-bold text-slime-text mb-4">Contact</h4>
                    <ul className="space-y-3 text-sm text-slime-text/60">
                        <li className="flex items-center gap-2"><Mail size={16} /> support@kuji.online</li>
                        <li className="flex items-center gap-2"><HelpCircle size={16} /> Live Chat (9am - 6pm)</li>
                    </ul>
                </div>
            </div>
            <div className="text-center text-xs text-slime-text/30 pt-8 border-t border-slime-bg">
                © 2024 Kuji Online Demo. All rights reserved.
            </div>
        </div>
    </footer>
  );

  // --- Views ---

  if (view === 'home') {
      return (
          <div className="min-h-screen bg-slime-bg flex flex-col font-sans">
              <Header />
              
              {/* Hero Section */}
              <div className="max-w-7xl mx-auto px-4 md:px-8 pt-8 pb-12 w-full">
                  <div className="bg-gradient-to-r from-slime-primary to-slime-secondary rounded-4xl p-8 md:p-16 text-white shadow-soft relative overflow-hidden flex items-center min-h-[400px]">
                      {/* Decorative Circles */}
                      <div className="absolute top-0 right-0 w-64 h-64 bg-white/20 rounded-full -translate-y-1/2 translate-x-1/4 blur-3xl"></div>
                      <div className="absolute bottom-0 left-0 w-96 h-96 bg-slime-accent/20 rounded-full translate-y-1/3 -translate-x-1/4 blur-3xl"></div>
                      
                      <div className="relative z-10 max-w-xl">
                          <span className="inline-block bg-white/30 backdrop-blur-sm px-4 py-1 rounded-full text-xs font-bold mb-6 border border-white/40">
                              NEW ARRIVALS
                          </span>
                          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight tracking-tight drop-shadow-sm">
                              Win Your <br/> Favorites
                          </h1>
                          <p className="text-lg md:text-xl opacity-90 mb-10 font-medium">
                              Play Ichiban Kuji online from anywhere. <br/> 
                              Real prizes, real fun, delivered to your door.
                          </p>
                          <button onClick={() => document.getElementById('products')?.scrollIntoView({behavior: 'smooth'})} className="bg-white text-slime-accent px-8 py-4 rounded-full font-bold text-lg shadow-lg hover:shadow-xl hover:scale-105 transition-all flex items-center gap-2">
                              Start Playing <ChevronRight size={20} />
                          </button>
                      </div>
                      
                      {/* Hero Image */}
                      <div className="absolute right-0 bottom-0 w-1/2 h-full hidden md:flex items-end justify-center pointer-events-none">
                          <img src="https://picsum.photos/seed/animegirl/600/800" className="max-h-[110%] object-contain drop-shadow-2xl animate-float" alt="Hero" />
                      </div>
                  </div>
              </div>

              {/* Features Section */}
              <div className="bg-white py-16">
                  <div className="max-w-7xl mx-auto px-8">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                          <div className="p-6">
                              <div className="w-16 h-16 bg-slime-bg rounded-2xl flex items-center justify-center text-slime-accent mx-auto mb-6">
                                  <Star size={32} fill="currentColor" />
                              </div>
                              <h3 className="font-bold text-lg text-slime-text mb-2">Authentic Prizes</h3>
                              <p className="text-slime-text/60 text-sm">100% official merchandise from Japan's top anime and game series.</p>
                          </div>
                          <div className="p-6">
                              <div className="w-16 h-16 bg-slime-bg rounded-2xl flex items-center justify-center text-slime-accent mx-auto mb-6">
                                  <Sparkles size={32} fill="currentColor" />
                              </div>
                              <h3 className="font-bold text-lg text-slime-text mb-2">Instant Wins</h3>
                              <p className="text-slime-text/60 text-sm">See your results immediately. No waiting, just exciting reveals.</p>
                          </div>
                          <div className="p-6">
                              <div className="w-16 h-16 bg-slime-bg rounded-2xl flex items-center justify-center text-slime-accent mx-auto mb-6">
                                  <Gift size={32} fill="currentColor" />
                              </div>
                              <h3 className="font-bold text-lg text-slime-text mb-2">Global Shipping</h3>
                              <p className="text-slime-text/60 text-sm">We ship your winnings directly to your doorstep, anywhere in the world.</p>
                          </div>
                      </div>
                  </div>
              </div>

              {/* Products Section */}
              <div id="products" className="max-w-7xl mx-auto px-4 md:px-8 py-16">
                  <div className="flex items-center justify-between mb-10">
                      <h2 className="text-3xl font-bold text-slime-text">All Collections</h2>
                      <button onClick={handleGenerateNew} disabled={isGenerating} className="flex items-center gap-2 text-slime-accent font-bold hover:bg-slime-bg px-4 py-2 rounded-full transition-colors">
                          {isGenerating ? <Loader2 className="animate-spin" /> : <Plus size={20} />}
                          AI Generate
                      </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                      {lotteries.map(lottery => {
                          const remaining = lottery.tickets.filter(t => !t.isOpened).length;
                          return (
                              <div key={lottery.id} className="group bg-white rounded-3xl p-4 shadow-soft hover:shadow-hover transition-all duration-500 hover:-translate-y-2 border border-transparent hover:border-slime-bg">
                                  <div className="relative aspect-[4/5] rounded-2xl overflow-hidden mb-4 bg-gray-100">
                                      <img src={lottery.coverImage} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                                      <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur px-3 py-1.5 rounded-xl text-xs font-bold text-slime-text shadow-sm">
                                          {lottery.pricePerTicket} P
                                      </div>
                                      {remaining === 0 && (
                                          <div className="absolute inset-0 bg-black/50 flex items-center justify-center backdrop-blur-sm">
                                              <span className="text-white font-bold border-2 border-white px-4 py-1 rounded-full -rotate-12">SOLD OUT</span>
                                          </div>
                                      )}
                                  </div>
                                  <div className="px-1">
                                      <div className="flex justify-between items-center mb-2">
                                          <span className="text-[10px] font-bold text-slime-accent bg-slime-bg px-2 py-1 rounded-md uppercase tracking-wide">{lottery.theme}</span>
                                          <span className="text-xs font-bold text-slime-text/40">{remaining}/{lottery.totalTickets} Left</span>
                                      </div>
                                      <h3 className="font-bold text-slime-text text-lg leading-tight mb-4 line-clamp-2 min-h-[3rem]">{lottery.title}</h3>
                                      <button 
                                          onClick={() => handlePlayClick(lottery.id)}
                                          className="w-full bg-slime-bg text-slime-accent font-bold py-3 rounded-xl hover:bg-slime-accent hover:text-white transition-all shadow-sm group-hover:shadow-md flex items-center justify-center gap-2"
                                      >
                                          {remaining > 0 ? 'Play Now' : 'View Results'}
                                      </button>
                                  </div>
                              </div>
                          )
                      })}
                  </div>
              </div>

              {/* FAQ Section */}
              <div className="bg-white py-16 border-t border-slime-bg">
                  <div className="max-w-3xl mx-auto px-8">
                      <h2 className="text-3xl font-bold text-slime-text text-center mb-12">Questions?</h2>
                      <div className="space-y-4">
                          {[
                              "How do I purchase points?",
                              "When will my prizes arrive?",
                              "Can I trade prizes with other users?",
                              "Is this service available internationally?"
                          ].map((q, i) => (
                              <div key={i} className="border border-slime-bg rounded-2xl p-6 hover:shadow-soft transition-all cursor-pointer group">
                                  <div className="flex justify-between items-center">
                                      <h4 className="font-bold text-slime-text group-hover:text-slime-accent transition-colors">{q}</h4>
                                      <Plus size={20} className="text-slime-text/30" />
                                  </div>
                              </div>
                          ))}
                      </div>
                  </div>
              </div>

              <Footer />
              {showLoginModal && <LoginScreen onLogin={handleLogin} onClose={() => setShowLoginModal(false)} />}
          </div>
      );
  }

  // Detail View
  return (
    <div className="min-h-screen bg-slime-bg flex flex-col font-sans">
        <Header />
        
        <div className="flex-1 max-w-7xl mx-auto w-full px-4 md:px-8 py-8 flex flex-col lg:flex-row gap-8">
            {/* Left: Info & Prizes */}
            <div className="w-full lg:w-96 flex flex-col gap-6 order-2 lg:order-1 h-fit">
               <button onClick={() => setView('home')} className="flex items-center gap-2 text-slime-text/60 hover:text-slime-accent font-bold pl-2">
                   <ArrowLeft size={20} /> Back to Shop
               </button>
               
               {currentLottery && (
                   <div className="bg-white rounded-3xl p-6 shadow-soft border border-slime-bg">
                       <img src={currentLottery.coverImage} className="w-full aspect-video object-cover rounded-2xl mb-4" />
                       <h1 className="text-xl font-bold text-slime-text mb-2">{currentLottery.title}</h1>
                       <div className="flex items-center gap-4 text-sm font-bold text-slime-text/60">
                           <span>{currentLottery.pricePerTicket} Points / Play</span>
                       </div>
                   </div>
               )}

               {currentLottery && <PrizeBoard prizes={currentLottery.prizes} lastOne={currentLottery.lastOnePrize} />}
            </div>

            {/* Right: Grid */}
            <div className="flex-1 order-1 lg:order-2">
                <div className="bg-gradient-to-r from-slime-primary to-slime-secondary rounded-3xl p-8 mb-8 text-white flex justify-between items-center shadow-soft">
                     <div>
                         <h2 className="text-2xl font-bold mb-1">Pick Your Ticket</h2>
                         <p className="opacity-90 text-sm">Good luck! Find the hidden treasures.</p>
                     </div>
                     <div className="bg-white/20 backdrop-blur px-6 py-2 rounded-2xl font-black text-2xl border border-white/30">
                         {currentLottery?.pricePerTicket} P
                     </div>
                </div>

                {currentLottery && <TicketGrid tickets={currentLottery.tickets} onTicketClick={handleTicketClick} />}
            </div>
        </div>

        <Footer />
        
        {/* Modals */}
        {showLoginModal && <LoginScreen onLogin={handleLogin} onClose={() => setShowLoginModal(false)} />}
        <AnimationModal 
         prizeTier={revealingTicket?.tier || null}
         prizeDetails={revealingTicket ? currentLottery?.prizes.find(p => p.tier === revealingTicket.tier) : undefined} 
         onClose={handleModalClose}
       />
    </div>
  );
};

export default App;