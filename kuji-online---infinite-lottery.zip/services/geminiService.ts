import { GoogleGenAI, Type } from "@google/genai";
import { LotterySet, Prize, Ticket, PrizeTier } from "../types";

const generateLotteryTickets = (prizes: Prize[], totalTickets: number): Ticket[] => {
  const ticketPool: PrizeTier[] = [];
  
  // Fill pool based on prize counts
  prizes.forEach(p => {
    for(let i=0; i<p.totalCount; i++) {
      ticketPool.push(p.tier);
    }
  });

  // Shuffle logic (Fisher-Yates)
  for (let i = ticketPool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [ticketPool[i], ticketPool[j]] = [ticketPool[j], ticketPool[i]];
  }

  // Create Ticket objects
  return ticketPool.map((tier, index) => ({
    id: index + 1,
    isOpened: false,
    prizeTier: tier
  }));
};

export const generateAiLottery = async (themePrompt: string): Promise<LotterySet> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) throw new Error("API Key missing");

  const ai = new GoogleGenAI({ apiKey });

  const systemInstruction = `You are an expert game designer for Japanese Ichiban Kuji (Lottery) systems. 
  Create a balanced lottery set based on the user's requested theme.
  Typical structure: 
  - 80 tickets total.
  - Grade A (Top prize): 2-3 items.
  - Grade B: 3-5 items.
  - Grade C: 5-10 items.
  - Lower grades (D, E, F...): Fill the rest.
  - "Last One" prize: A special variant of Grade A.
  
  Return valid JSON. Use https://picsum.photos/seed/{random_string}/400/400 for images.`;

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `Create a lottery set with theme: "${themePrompt}". Total tickets should be 80.`,
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          prizes: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                tier: { type: Type.STRING, enum: ["A", "B", "C", "D", "E", "F", "G", "H"] },
                name: { type: Type.STRING },
                description: { type: Type.STRING },
                totalCount: { type: Type.INTEGER },
                imageSeed: { type: Type.STRING }
              },
              required: ["tier", "name", "totalCount", "imageSeed", "description"]
            }
          },
          lastOnePrize: {
             type: Type.OBJECT,
             properties: {
                name: { type: Type.STRING },
                description: { type: Type.STRING },
                imageSeed: { type: Type.STRING }
             },
             required: ["name", "imageSeed", "description"]
          }
        },
        required: ["title", "description", "prizes", "lastOnePrize"]
      }
    }
  });

  const data = JSON.parse(response.text || "{}");
  
  // Transform to App Types
  const mappedPrizes: Prize[] = data.prizes.map((p: any) => ({
    tier: p.tier as PrizeTier,
    name: p.name,
    description: p.description,
    totalCount: p.totalCount,
    currentCount: p.totalCount,
    image: `https://picsum.photos/seed/${p.imageSeed}/500/500`
  }));

  const lastOne: Prize = {
    tier: 'LastOne',
    name: data.lastOnePrize.name,
    description: data.lastOnePrize.description,
    totalCount: 1,
    currentCount: 1,
    image: `https://picsum.photos/seed/${data.lastOnePrize.imageSeed}/500/500`
  };

  // Ensure total matches 80 or adjust
  const currentTotal = mappedPrizes.reduce((sum, p) => sum + p.totalCount, 0);
  const tickets = generateLotteryTickets(mappedPrizes, currentTotal);

  return {
    id: `ai-${Date.now()}`,
    title: data.title,
    theme: themePrompt,
    description: data.description,
    pricePerTicket: 350,
    currency: 'NTD',
    totalTickets: currentTotal,
    prizes: mappedPrizes,
    lastOnePrize: lastOne,
    coverImage: `https://picsum.photos/seed/${data.title}/800/600`,
    tickets: tickets
  };
}

// Initial Mock Data for Chiikawa (The user requested this specifically)
export const getInitialChiikawaSet = (): LotterySet => {
  const prizes: Prize[] = [
    { tier: 'A', name: 'Giant Chiikawa Plush (Pajama Ver.)', totalCount: 2, currentCount: 2, description: 'Super soft 40cm plushie.', image: 'https://picsum.photos/seed/chiikawaA/500/500' },
    { tier: 'B', name: 'Hachiware Figure (Cooking)', totalCount: 3, currentCount: 3, description: 'Detailed vinyl figure.', image: 'https://picsum.photos/seed/chiikawaB/500/500' },
    { tier: 'C', name: 'Usagi Fluffy Blanket', totalCount: 5, currentCount: 5, description: 'Warm fleece blanket.', image: 'https://picsum.photos/seed/chiikawaC/500/500' },
    { tier: 'D', name: 'Character Mug Cup', totalCount: 15, currentCount: 15, description: 'Ceramic mug with random design.', image: 'https://picsum.photos/seed/chiikawaD/500/500' },
    { tier: 'E', name: 'Jacquard Hand Towel', totalCount: 25, currentCount: 25, description: '100% Cotton towel.', image: 'https://picsum.photos/seed/chiikawaE/500/500' },
    { tier: 'F', name: 'Acrylic Charm / Keychain', totalCount: 30, currentCount: 30, description: 'Collect them all!', image: 'https://picsum.photos/seed/chiikawaF/500/500' },
  ];

  const lastOne: Prize = {
    tier: 'LastOne',
    name: 'Special Chiikawa & Hachiware Hugging Plush',
    totalCount: 1,
    currentCount: 1,
    description: 'Exclusive prize for the last ticket!',
    image: 'https://picsum.photos/seed/chiikawaLast/500/500'
  };

  const total = prizes.reduce((acc, p) => acc + p.totalCount, 0);
  
  return {
    id: 'chiikawa-001',
    title: 'Chiikawa: Everyday Fun Collection',
    theme: 'Chiikawa',
    description: 'The adorable Chiikawa gang is here! Try your luck to get the giant Pajama Plush.',
    pricePerTicket: 300,
    currency: 'NTD',
    totalTickets: total,
    prizes: prizes,
    lastOnePrize: lastOne,
    tickets: generateLotteryTickets(prizes, total),
    coverImage: 'https://picsum.photos/seed/chiikawaCover/800/600'
  };
};
